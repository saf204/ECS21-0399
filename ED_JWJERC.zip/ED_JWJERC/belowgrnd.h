#ifndef _BELOWGRND_H_
#define _BELOWGRND_H_

#include "edmodels.h"
/*
#if defined ED
void Dwdt (struct site **siteptr, struct patch **patchptr, 
           double time, struct UserData *data); 
void Dsdt (struct site **siteptr, struct patch **patchptr, 
           unsigned int time_period, double time, struct UserData *data);
#elif defined MIAMI_LU
void Dsdt(struct site **siteptr, struct patch **patchptr, struct UserData *data);
#endif 
*/

#endif /* _BELOWGRND_H_ */
