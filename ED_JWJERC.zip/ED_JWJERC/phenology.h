#ifndef EDM_PHENOLOGY_H_
#define EDM_PHENOLOGY_H_

#include "edmodels.h"

void phenology (int t, patch** patchptr, UserData* data);
void new_phenology (int t, patch** patchptr, UserData* data);

#endif // EDM_PHENOLOGY_H_ 
