#ifndef EDM_MIAMI_H_
#define EDM_MIAMI_H_

double miami (double precipitation, double temperature);

#endif // EDM_MIAMI_H_ 
