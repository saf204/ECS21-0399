#ifndef _ALLOMETRY_H_
#define _ALLOMETRY_H_

#include "edmodels.h"

//double Dbh     (struct cohort **pcurrentp, struct UserData *data);
//double Hite    (struct cohort **pcurrentp, struct UserData *data);
//double Bleaf   (struct cohort **pcurrentp, struct UserData *data);
//double Bdead   (struct cohort **pcurrentp, struct UserData *data);
//double dHdBd   (struct cohort **pcurrentp, struct UserData *data);
//double dDbhdBd (struct cohort **pcurrentp, struct UserData *data);
//double dDbhdBl (struct cohort **pcurrentc, struct UserData *data);

#endif /* _ALLOMETRY_H_ */
