import Nio
import numpy as np

fname = "/Network/Xgrid/output/edlu/steve/migration_2014/agu_2014/mig_2015/"


echeck = np.zeros((8))


#everlon
number = 101
for x in range (100,110):
   year = (30,60,90,120,150,180)
   expected = (60,100,140,180,220,259)
   name = fname +"ever_lon" + str(x) + "/ever_lon"+str(x)+".region.nc"
   f = Nio.open_file(name,'r')
   grid = np.zeros((441,20,20))
   grid[:,:,:] = f.variables['agb'][:,:,:]
   count = 0
   for v in range (0,6):
      for dim1 in range (0,20):
         for dim2 in range (0,20):
            agb = grid[year[v],dim1,dim2]
            if agb >0:
               count+=1
      error = float(count)/expected[v]
      echeck[v] = error + echeck[v]
      print str(year[v]) + " " +str(expected[v])+ " " +str(count)+" " + str(error)
      count = 0
   f.close()

echeck/=100
print echeck
   
#everlat
number = 101
for x in range (100,110):
   year = (55,110,165,220,275,330)
   expected = (60,100,140,180,220,255)
   name = fname +"ever_lat" + str(x) + "/ever_lat"+str(x)+".region.nc"
   f = Nio.open_file(name,'r')
   grid = np.zeros((441,20,20))
   grid[:,:,:] = f.variables['agb'][:,:,:]
   count = 0
   for v in range (0,6):
      for dim1 in range (0,20):
         for dim2 in range (0,20):
            agb = grid[year[v],dim1,dim2]
            if agb >1:
               count+=1
      error = float(count)/expected[v]
      echeck[v] = error + echeck[v]
      print str(year[v]) + " " +str(expected[v])+ " " +str(count)+" " + str(error)
      count = 0
   f.close()

echeck/=100
print echeck